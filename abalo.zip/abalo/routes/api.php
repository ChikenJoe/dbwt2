<?php

use App\Http\Controllers\ApiArticles;
use App\Http\Controllers\ApiShoppingCart;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::get('/articles', [ApiArticles::class, 'index']);
Route::post('/articles', [ApiArticles::class, 'store']);
Route::delete('/articles/{id}', [ApiArticles::class, 'destroy']);

Route::get('/shoppingcart', [ApiShoppingCart::class, 'index']);
Route::post('/shoppingcart', [ApiShoppingCart::class, 'store']);
Route::delete('/shoppingcart/{shoppingcartid}/articles/{articleId}', [ApiShoppingCart::class, 'destroy']);
