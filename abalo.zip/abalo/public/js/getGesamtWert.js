function getGesamtWert(data){
    let gesamtWert = 0;
    let products = data['produkte'];
    let formatter = new Intl.NumberFormat('de-DE',{
        style: 'currency',
        currency: 'EUR'
    });

    products.forEach(function(product, index){
        gesamtWert += product.preis * product.anzahl;
    });

    alert("Gesamtwert aller Produkte: " + formatter.format(gesamtWert));
    return gesamtWert;
}

/*
* var data = {
    'produkte': [
        { name: 'Ritterburg', preis: 59.99, kategorie: 1, anzahl: 3 },
        { name: 'Gartenschlau 10m', preis: 6.50, kategorie: 2, anzahl: 5 },
        { name: 'Robomaster' ,preis: 199.99, kategorie: 1, anzahl: 2 },
        { name: 'Pool 250x400', preis: 250, kategorie: 2, anzahl: 8 },
        { name: 'Rasenmähroboter', preis: 380.95, kategorie: 2, anzahl: 4 },
        { name: 'Prinzessinnenschloss', preis: 59.99, kategorie: 1, anzahl: 5 }
    ],
    'kategorien': [
        { id: 1, name: 'Spielzeug' },
        { id: 2, name: 'Garten' }
    ]
};
* */
