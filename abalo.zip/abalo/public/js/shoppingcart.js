/*document.addEventListener('DOMContentLoaded', () =>{
    //var shoppingCartItems
    //var articles
    //  Initialize shopping cart with database stock.
    const itemlist = document.getElementById('cart-items');

    shoppingCartItems.forEach(item => {
        articles.forEach(article => {
            if (item.ab_article_id == article.id){
                const listelement = document.createElement('li');
                const removeButton = document.createElement('button');

                listelement.innerText = article.ab_name;
                removeButton.innerText = '-';


                document.querySelectorAll(".add-to-cart").forEach((button) => {
                    const buttonId = button.closest('tr').getAttribute('data-id');
                    if (buttonId == article.id){
                        console.log(buttonId);
                        button.disabled = true;
                    }
                });

                removeButton.addEventListener('click', (event) => {
                    let xhr = new XMLHttpRequest();
                    const csrf = document.getElementById('csrf-token').content;
                    xhr.open('DELETE', `api/shoppingcart/1/articles/${article.id}`);

                    xhr.setRequestHeader('X-CSRF-TOKEN', csrf);
                    xhr.onload = function(){
                        if (xhr.status === 200){
                            const list_el_to_remove = event.target.closest('li');
                            list_el_to_remove.remove();
                            document.querySelectorAll(".add-to-cart").forEach((button) => {
                                const buttonId = button.closest('tr').getAttribute('data-id');
                                if (buttonId == article.id){
                                    console.log(buttonId);
                                    button.disabled = false;
                                }
                            });
                        }
                        else
                            alert("Couldnt delete item from cart");
                    }

                    xhr.send();
                });

                listelement.appendChild(removeButton);
                itemlist.appendChild(listelement);
            }
        })
    });

    document.querySelectorAll(".add-to-cart").forEach((button) =>{
        //Disable + button for initialized items

        button.addEventListener('click', (event) =>{
            const itemlist = document.getElementById('cart-items');

            const articleRow = event.target.closest('tr');
            const articleName = articleRow.querySelector('td:first-child').textContent;
            const articleId = articleRow.getAttribute('data-id');
            console.log("articleId: " + articleId);

            const postobj = {articleId:articleId};
            const post = JSON.stringify(postobj);
            const csrf = document.getElementById('csrf-token').content;

            const removeButton = document.createElement('button');
            removeButton.innerText = '-';

            const addButton = event.target;
            removeButton.addEventListener('click', (event) => {
                let xhr = new XMLHttpRequest();
                xhr.open('DELETE', `api/shoppingcart/1/articles/${articleId}`);
                xhr.setRequestHeader('X-CSRF-TOKEN', csrf);
                xhr.onload = function(){
                    if (xhr.status === 200){
                        const list_el_to_remove = event.target.closest('li');
                        list_el_to_remove.remove();
                        addButton.disabled = false;
                    }
                    else
                        alert("Couldnt delete item from cart");
                }

                xhr.send();
            });

            let xhr = new XMLHttpRequest();
            xhr.open('POST', '/api/shoppingcart');
            xhr.setRequestHeader('X-CSRF-TOKEN', csrf);
            xhr.setRequestHeader('Content-Type', 'application/json');


            xhr.onload = function(){
                if (xhr.status === 200){
                    const listelement = document.createElement('li');
                    listelement.innerText = articleName;
                    listelement.appendChild(removeButton);
                    itemlist.appendChild(listelement);
                    event.target.disabled = true;
                }
            }

            xhr.send(post);
        });
    });
});
*/
document.addEventListener('DOMContentLoaded', () => {
    const cartItemsList = document.getElementById('cart-items');
    const csrfToken = document.getElementById('csrf-token').content;
    const SHOPPING_CART_ID = 1; // Consider making this dynamic if needed

    // Create article lookup map for better performance
    const articleMap = new Map(articles.map(article => [article.id, article]));

    // Helper functions
    const createCartItemElement = (article, cartId) => {
        const li = document.createElement('li');
        const removeBtn = document.createElement('button');
        removeBtn.textContent = '-';

        li.textContent = article.ab_name;
        li.appendChild(removeBtn);
        li.dataset.articleId = article.id;

        removeBtn.addEventListener('click', () => handleRemoveItem(article.id, cartId, li));
        return li;
    };

    const toggleAddButton = (articleId, disabled) => {
        document.querySelectorAll('.add-to-cart').forEach(button => {
            const buttonArticleId = button.closest('tr').dataset.id;
            if (buttonArticleId === articleId.toString()) {
                button.disabled = disabled;
            }
        });
    };

    const handleRemoveItem = async (articleId, cartId, listElement) => {
        try {
            const response = await fetch(`/api/shoppingcart/${cartId}/articles/${articleId}`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': csrfToken
                }
            });

            if (!response.ok) throw new Error('Failed to remove item');

            listElement.remove();
            toggleAddButton(articleId, false);
        } catch (error) {
            console.error('Error removing item:', error);
            alert('Could not remove item from cart');
        }
    };

    // Initialize cart items
    shoppingCartItems.forEach(item => {
        const article = articleMap.get(item.ab_article_id);
        if (article) {
            const listItem = createCartItemElement(article, SHOPPING_CART_ID);
            cartItemsList.appendChild(listItem);
            toggleAddButton(article.id, true);
        }
    });

    // Add to cart event handlers
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', async (event) => {
            const row = event.target.closest('tr');
            const articleId = row.dataset.id;
            const article = articleMap.get(parseInt(articleId));

            if (!article) return;

            try {
                const response = await fetch('/api/shoppingcart', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': csrfToken,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ articleId })
                });

                if (!response.ok) throw new Error('Failed to add item');

                const listItem = createCartItemElement(article, SHOPPING_CART_ID);
                cartItemsList.appendChild(listItem);
                event.target.disabled = true;
            } catch (error) {
                console.error('Error adding item:', error);
                alert('Could not add item to cart');
            }
        });
    });
});
