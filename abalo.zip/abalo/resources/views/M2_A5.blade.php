<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="utf-8">
    <title>Laravel</title>
    <script src="{{ asset('/js/data.js') }}"></script>
</head>
<body>
    <script src="{{ asset('/js/getMaxPreis.js') }}"></script>
    <script src="{{ asset('/js/getMinPreisProdukt.js') }}"></script>
    <script src="{{ asset('/js/getPreisSum.js') }}"></script>
    <script src="{{ asset('/js/getGesamtWert.js') }}"></script>
    <script src="{{ asset('/js/getAnzahlProdukteOfKategorie.js') }}"></script>
    <script>
        getMaxPreis(data);
        getMinPreisProdukt(data);
        getPreisSum(data);
        getGesamtWert(data);
        getAnzahlProdukteOfKategorie(data, 'Garten');
    </script>
</body>
</html>
