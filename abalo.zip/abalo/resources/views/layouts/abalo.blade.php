<!DOCTYPE html>
<html>
<head>
    <meta charset = "UTF-8">
    <meta id ="csrf-token" name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="{{ asset('/css/abalo.css') }}">
    <title>@yield('title')</title>
</head>
<body class ="modal-active">
    <div id ="top">@yield('top')</div>
    <div id="container">
        <div id ="left">@yield('left')</div>
        <div id ="middle">@yield('middle')</div>
        <div id ="right">@yield('right')</div>
    </div>
</body>
<footer>
    <div id="footer">@yield('footer')</div>
</footer>
</html>
