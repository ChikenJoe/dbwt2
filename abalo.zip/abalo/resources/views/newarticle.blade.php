<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Artikeleingabe</title>
</head>
<body>
<script src="{{asset('/js/add_article_form.js')}}"></script>
</body>
</html>
