<!DOCTYPE html>
<html>
<head>
    <meta charset = "UTF-8">
    <meta id ="csrf-token" name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/abalo.css')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body class ="modal-active">
    <div id ="top"><?php echo $__env->yieldContent('top'); ?></div>
    <div id="container">
        <div id ="left"><?php echo $__env->yieldContent('left'); ?></div>
        <div id ="middle"><?php echo $__env->yieldContent('middle'); ?></div>
        <div id ="right"><?php echo $__env->yieldContent('right'); ?></div>
    </div>
</body>
<footer>
    <div id="footer"><?php echo $__env->yieldContent('footer'); ?></div>
</footer>
</html>
<?php /**PATH D:\Studium\DBWT2\Praktikum\dbwt2-ss25\project-abalo\abalo\resources\views/layouts/abalo.blade.php ENDPATH**/ ?>