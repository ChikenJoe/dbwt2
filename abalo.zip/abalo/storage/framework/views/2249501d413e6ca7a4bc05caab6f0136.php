<script src = "<?php echo e(asset('/js/shoppingcart.js')); ?>"></script>
<script src = "<?php echo e(asset('/js/cookiecheck.js')); ?>"></script>
<script src = "<?php echo e(asset('/js/navMenuObject.js')); ?>"></script>
<script>
    var shoppingCartItems = <?php echo json_encode($shoppingcartitems, 15, 512) ?>;
    var articles = <?php echo json_encode($articles, 15, 512) ?>;
</script>

<?php $__env->startSection('top'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Welcome to Abalo!'); ?>

<?php $__env->startSection('right'); ?>
    <div id="cart">
        <h2 style="text-align: center">Warenkorb</h2>
        <ul id="cart-items">

        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('middle'); ?>
    <table border="1">
        <thead>
        <tr>
            <td>Name</td>
            <td>Price</td>
            <td>Description</td>
            <td>Bild</td>
            <td>Hinzufügen</td>
        </tr>
        </thead>

        <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr data-id="<?php echo e($article['id']); ?>">
                <td><?php echo e($article['ab_name']); ?></td>
                <td><?php echo e(number_format($article['ab_price'] / 100, 2)); ?>€</td>
                <td><?php echo e($article['ab_description']); ?></td>
                <td>
                    <?php if(!empty($article->image->ab_img_filename)): ?>
                        <img src="<?php echo e(asset('img/articleimages/' . $article->image->ab_img_filename)); ?>"
                             alt="Platzhalter"
                             height="128px"
                             width="192px">
                    <?php endif; ?>
                </td>
                <td>
                    <button class="add-to-cart">+</button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td> No item found </td>
            </tr>
        <?php endif; ?>
    </table>
    <?php $__env->stopSection(); ?>

    </body>
    </html>

<?php echo $__env->make('layouts.abalo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Studium\DBWT2\Praktikum\dbwt2-ss25\project-abalo\abalo\resources\views/start.blade.php ENDPATH**/ ?>