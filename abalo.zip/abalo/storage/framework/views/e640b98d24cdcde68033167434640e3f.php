<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Artikeleingabe</title>
</head>
<body>
<script src="<?php echo e(asset('/js/add_article_form.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\Studium\DBWT2\Praktikum\dbwt2-ss25\project-abalo\abalo\resources\views/newarticle.blade.php ENDPATH**/ ?>