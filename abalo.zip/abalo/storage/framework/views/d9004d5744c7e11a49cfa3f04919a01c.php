<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="utf-8">
    <title>Laravel</title>
    <script src="<?php echo e(asset('/js/data.js')); ?>"></script>
</head>
<body>
    <script src="<?php echo e(asset('/js/getMaxPreis.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/getMinPreisProdukt.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/getPreisSum.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/getGesamtWert.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/getAnzahlProdukteOfKategorie.js')); ?>"></script>
    <script>
        getMaxPreis(data);
        getMinPreisProdukt(data);
        getPreisSum(data);
        getGesamtWert(data);
        getAnzahlProdukteOfKategorie(data, 'Garten');
    </script>
</body>
</html>
<?php /**PATH D:\Studium\DBWT2\Praktikum\dbwt2-ss25\project-abalo\abalo\resources\views/M2_A5.blade.php ENDPATH**/ ?>