Gadi Alazar Yosef, 3203881
Lando Schulz, 3145837