<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Artikeleingabe</title>
</head>
<body>
<script>
    "use strict";
    document.addEventListener('DOMContentLoaded', function () {
        const form = document.createElement('form');
        form.id = 'articleForm';

        const nameInput = document.createElement('input');
        nameInput.type = 'text';
        nameInput.id = 'name';
        nameInput.placeholder = 'Artikelname';

        const priceInput = document.createElement('input');
        priceInput.type = 'number';
        priceInput.id = 'price';
        priceInput.placeholder = 'Preis';

        const descriptionInput = document.createElement('textarea');
        descriptionInput.id = 'description';
        descriptionInput.placeholder = 'Beschreibung';

        const submitButton = document.createElement('button');
        submitButton.type = 'button';
        submitButton.innerText = 'Speichern';
        submitButton.addEventListener('click', submitArticle);

        form.appendChild(nameInput);
        form.appendChild(priceInput);
        form.appendChild(descriptionInput);
        form.appendChild(submitButton);

        document.body.appendChild(form);

        // Feedback-Bereich hinzufügen
        const feedbackDiv = document.createElement('div');
        feedbackDiv.id = 'feedback';
        document.body.appendChild(feedbackDiv);
    });

    function submitArticle() {
        const name = document.getElementById('name').value.trim();
        const price = parseFloat(document.getElementById('price').value);
        const description = document.getElementById('description').value.trim();
        const feedbackDiv = document.getElementById('feedback');

        // Feedback-Reset
        feedbackDiv.innerHTML = '';

        // Validierung
        if (!name) {
            feedbackDiv.innerText = 'Der Artikelname darf nicht leer sein.';
            return;
        }
        if (isNaN(price) || price <= 0) {
            feedbackDiv.innerText = 'Der Preis muss eine Zahl sein und größer als 0 sein.';
            return;
        }

        // Daten absenden
        const formData = new FormData();
        formData.append('name', name);
        formData.append('price', price);
        formData.append('description', description);

        fetch('/articles', {
            method: 'POST',
            body: formData,
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
            },
        })
            .then((response) => {
                if (!response.ok) {
                    throw new Error('Server-Fehler: ' + response.status);
                }
                return response.json();
            })
            .then((data) => {
                if (data.success) {
                    feedbackDiv.innerText = 'Artikel erfolgreich gespeichert!';
                } else {
                    feedbackDiv.innerText = 'Fehler: ' + (data.message || 'Unbekannter Fehler');
                }
            })
            .catch((error) => {
                console.error('Fehler:', error);
                feedbackDiv.innerText = 'Ein Fehler ist aufgetreten: ' + error.message;
            });
    }

</script>
</body>
</html>
<?php /**PATH D:\Studium\DBWT2\Praktikum\dbwt2-ss25\project-abalo\abalo\resources\views/newarticle.blade.php ENDPATH**/ ?>