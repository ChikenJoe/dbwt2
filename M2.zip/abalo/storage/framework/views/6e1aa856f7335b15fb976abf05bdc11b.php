<!DOCTYPE html>
<html>
<head>
    <meta charset = "UTF-8">
    <style>
        nav ul {
            list-style: none;
            padding-left: 0;
        }

        nav > ul > li {
            display: inline-block;
            margin-right: 20px;
            position: relative;
        }

        nav ul li ul {
            display: block;
            position: absolute;
            top: 100%;
            left: 0;
            padding-left: 10px;
        }

        nav li {
            padding: 5px;
        }

        nav a {
            text-decoration: none;
            color: #333;
            font-weight: bold;
        }

        nav li ul li {
            display: block;
        }
    </style>
</head>
<body>
<script src="<?php echo e(asset('js/cookiecheck.js')); ?>"></script>

<nav id="navMenu"></nav>
<!--Von ChatGpt-->
<script>
    const menuData = [
        { title: "Home" },
        { title: "Kategorien" },
        { title: "Verkaufen" },
        {
            title: "Unternehmen",
            children: [
                { title: "Philosophie" },
                { title: "Karriere" }
            ]
        }
    ];

    function createMenu(menuItems) {
        const ul = document.createElement("ul");

        menuItems.forEach(item => {
            const li = document.createElement("li");
            const link = document.createElement("a");
            link.href = "#";
            link.textContent = item.title;
            li.appendChild(link);

            if (item.children && item.children.length > 0) {
                const subMenu = createMenu(item.children);
                li.appendChild(subMenu);
            }

            ul.appendChild(li);
        });

        return ul;
    }


    const navContainer = document.getElementById("navMenu");
    const menu = createMenu(menuData);
    navContainer.appendChild(menu);
</script>

<div id="cart">
    <h2>Warenkorb</h2>
    <ul id="cart-items"></ul>
</div>
<table>
    <thead>
    <tr>
        <td>Name</td>
        <td>Price</td>
        <td>Description</td>
        <td>Bild</td>
        <td>Hinzufügen</td>
    </tr>
    </thead>

    <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr data-id="<?php echo e($article['id']); ?>">
            <td><?php echo e($article['ab_name']); ?></td>
            <td><?php echo e(number_format($article['ab_price'] / 100, 2)); ?>€</td>
            <td><?php echo e($article['ab_description']); ?></td>
            <td>
                <?php if(!empty($article->image->ab_img_filename)): ?>
                    <img src="<?php echo e(asset('img/articleimages/' . $article->image->ab_img_filename)); ?>"
                         alt="Platzhalter"
                         height="128px"
                         width="192px">
                <?php endif; ?>
            </td>
            <td>
                <button class="add-to-cart">+</button>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="5"> No item found </td>
        </tr>
    <?php endif; ?>
</table>

<script>
    // JavaScript für den Warenkorb
    document.addEventListener("DOMContentLoaded", () => {
        const cart = new Set(); // Zum Speichern der Artikel-IDs

        const updateCartDisplay = () => {
            const cartItems = document.getElementById("cart-items");
            cartItems.innerHTML = "";

            cart.forEach((itemId) => {
                const articleRow = document.querySelector(`tr[data-id='${itemId}']`);
                if (articleRow) {
                    const listItem = document.createElement("li");
                    listItem.textContent = articleRow.querySelector("td:first-child").textContent;

                    const removeButton = document.createElement("button");
                    removeButton.textContent = "-";
                    removeButton.addEventListener("click", () => {
                        cart.delete(itemId);
                        articleRow.querySelector(".add-to-cart").disabled = false;
                        updateCartDisplay();
                    });

                    listItem.appendChild(removeButton);
                    cartItems.appendChild(listItem);
                }
            });
        };

        document.querySelectorAll(".add-to-cart").forEach((button) => {
            button.addEventListener("click", (event) => {
                const articleRow = event.target.closest("tr");
                const articleId = articleRow.getAttribute("data-id");

                if (!cart.has(articleId)) {
                    cart.add(articleId);
                    event.target.disabled = true; // Deaktiviert den Button
                    updateCartDisplay();
                }
            });
        });
    });
</script>
</body>
</html>
<?php /**PATH D:\Studium\DBWT2\Praktikum\dbwt2-ss25\project-abalo\abalo\resources\views/mainview.blade.php ENDPATH**/ ?>