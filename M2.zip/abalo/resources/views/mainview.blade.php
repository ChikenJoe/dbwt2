<!DOCTYPE html>
<html>
<head>
    <meta charset = "UTF-8">
    <style>
        nav ul {
            list-style: none;
            padding-left: 0;
        }

        nav > ul > li {
            display: inline-block;
            margin-right: 20px;
            position: relative;
        }

        nav ul li ul {
            display: block;
            position: absolute;
            top: 100%;
            left: 0;
            padding-left: 10px;
        }

        nav li {
            padding: 5px;
        }

        nav a {
            text-decoration: none;
            color: #333;
            font-weight: bold;
        }

        nav li ul li {
            display: block;
        }
    </style>
</head>
<body>
<script src="{{ asset('js/cookiecheck.js') }}"></script>

<nav id="navMenu"></nav>
<!--Von ChatGpt-->
<script>
    const menuData = [
        { title: "Home" },
        { title: "Kategorien" },
        { title: "Verkaufen" },
        {
            title: "Unternehmen",
            children: [
                { title: "Philosophie" },
                { title: "Karriere" }
            ]
        }
    ];

    function createMenu(menuItems) {
        const ul = document.createElement("ul");

        menuItems.forEach(item => {
            const li = document.createElement("li");
            const link = document.createElement("a");
            link.href = "#";
            link.textContent = item.title;
            li.appendChild(link);

            if (item.children && item.children.length > 0) {
                const subMenu = createMenu(item.children);
                li.appendChild(subMenu);
            }

            ul.appendChild(li);
        });

        return ul;
    }


    const navContainer = document.getElementById("navMenu");
    const menu = createMenu(menuData);
    navContainer.appendChild(menu);
</script>

<div id="cart">
    <h2>Warenkorb</h2>
    <ul id="cart-items"></ul>
</div>
<table>
    <thead>
    <tr>
        <td>Name</td>
        <td>Price</td>
        <td>Description</td>
        <td>Bild</td>
        <td>Hinzufügen</td>
    </tr>
    </thead>

    @forelse($articles as $article)
        <tr data-id="{{ $article['id'] }}">
            <td>{{$article['ab_name']}}</td>
            <td>{{ number_format($article['ab_price'] / 100, 2) }}€</td>
            <td>{{$article['ab_description']}}</td>
            <td>
                @if (!empty($article->image->ab_img_filename))
                    <img src="{{ asset('img/articleimages/' . $article->image->ab_img_filename) }}"
                         alt="Platzhalter"
                         height="128px"
                         width="192px">
                @endif
            </td>
            <td>
                <button class="add-to-cart">+</button>
            </td>
        </tr>
    @empty
        <tr>
            <td colspan="5"> No item found </td>
        </tr>
    @endforelse
</table>

<script>
    // JavaScript für den Warenkorb
    document.addEventListener("DOMContentLoaded", () => {
        const cart = new Set(); // Zum Speichern der Artikel-IDs

        const updateCartDisplay = () => {
            const cartItems = document.getElementById("cart-items");
            cartItems.innerHTML = "";

            cart.forEach((itemId) => {
                const articleRow = document.querySelector(`tr[data-id='${itemId}']`);
                if (articleRow) {
                    const listItem = document.createElement("li");
                    listItem.textContent = articleRow.querySelector("td:first-child").textContent;

                    const removeButton = document.createElement("button");
                    removeButton.textContent = "-";
                    removeButton.addEventListener("click", () => {
                        cart.delete(itemId);
                        articleRow.querySelector(".add-to-cart").disabled = false;
                        updateCartDisplay();
                    });

                    listItem.appendChild(removeButton);
                    cartItems.appendChild(listItem);
                }
            });
        };

        document.querySelectorAll(".add-to-cart").forEach((button) => {
            button.addEventListener("click", (event) => {
                const articleRow = event.target.closest("tr");
                const articleId = articleRow.getAttribute("data-id");

                if (!cart.has(articleId)) {
                    cart.add(articleId);
                    event.target.disabled = true; // Deaktiviert den Button
                    updateCartDisplay();
                }
            });
        });
    });
</script>
</body>
</html>
