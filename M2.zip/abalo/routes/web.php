<?php

use App\Http\Controllers\AbTestDataController;
use Illuminate\Support\Facades\Route;

//  what is "function" ?
Route::get('/', function () {
    return view('welcome');
});

//  Is this a lambda ?
Route::get('/testdata', [AbTestDataController::class, 'getTestData']);

Route::get('/login', [App\Http\Controllers\AuthController::class, 'login'])->name('login');
Route::get('/logout', [App\Http\Controllers\AuthController::class, 'logout'])->name('logout');
Route::get('/isloggedin', [App\Http\Controllers\AuthController::class, 'isloggedin'])->name('haslogin');
Route::get('/articles', [AbTestDataController::class, 'getArticleData']);
Route::post('/articles', [AbTestDataController::class, 'store']);
Route::get('/newarticle', [AbTestDataController::class, 'newArticle']);

//js views
Route::get('a5', function(){ return view('m2js');});

//Route::get('createUsers', [AbTestDataController::class, 'generateUsers']);
//user sollen noch nicht generiert werden, so wie ich es verstanden habe
